Required Python Packages
    pytorch >= 1.2
    random 
    argparse
    numpy
    tqdm
    PIL 
    re
    matplotlib 
    
Recommend Packages
    tensorboard >= 2.0
    
    

Required Steps for Training:

1- Training the encoder h        

   1.1 cifar10:  python train_encoder.py --dataset=cifar10 
   1.2 cifar100: python train_encoder.py --dataset=cifar100  
   
notice that:
  1- checkpoint is saved under ./checkpoint/{args.dataset}_{args.h_dim}_bs{args.bs}_hlr{args.h_lr}_temp{args.temprature}_h_nt.pt 
  2- different hyperparamter rather than what mentioned in the paper can be passed by arguments 
   
   
2- Training the discriminator s 
 (* it's neccesary to pass the already the path to trained h as an argument)
 
  2.1 cifar10: python train_discriminator.py --dataset=cifar10  --h_net_path=<path to the trained h corresponding to the required dataset> 
  
  2.2 cifar100: python train_discriminator.py --dataset=cifar10  --h_net_path=<path to the trained h corresponding to the required dataset> 
  
  
3- Evaluating the discriminator s
  3.1 cifar10 vs svhn:  python roc.py --dataset=cifar10 --ood_dataset=svhn  --h_net_path=<path to encoder h trained on cifar10> --s_net_path=<path to discriminator s trained on cifar10 >
  
  3.2 cifar100 vs svhn:  python roc.py --dataset=cifar100 --ood_dataset=svhn  --h_net_path=<path to encoder h trained on cifar100> --s_net_path=<path to discriminator s trained on cifar100 >
  
  3.3 cifar10 vs cifar100:  python roc.py --dataset=cifar10 --ood_dataset=cifar100  --h_net_path=<path to encoder h trained on cifar10> --s_net_path=<path to discriminator s trained on cifar10 >
  
  3.4 cifar100 vs cifar10:  python roc.py --dataset=cifar100 --ood_dataset=cifar10  --h_net_path=<path to encoder h trained on cifar100> --s_net_path=<path to discriminator s trained on cifar100 >  
  