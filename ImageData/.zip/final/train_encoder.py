import os 
import torch
from torch import nn, optim
import random
import argparse
from tqdm import tqdm
import numpy as np
from dataset_wrapper import DataSetWrapper
from torchvision.models.resnet import resnet34
from utils import  avg_NCE_loss, count_parameters
from change_resnet import modify_resnet_model

vis = True
try:
    from torch.utils.tensorboard import SummaryWriter
except:
    vis = False 
    
wt = 0.001
similarity = nn.CosineSimilarity(dim=1)
device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

def train(epoch, args, loader1, loader2, h_net, h_net_opt):        
    loader2 = tqdm(loader2)    
    h_net.train()    
    
    data_itr = iter(loader1)    
    (_, img_r, _), _ = next(data_itr)
    img_r = img_r.to(device)            
    for itr, ((img_norm, img_t1, img_t2), label) in enumerate(loader2): 
        bs = img_t1.size(0)
        h_net.zero_grad()        
        img_t1, img_t2  = img_t1.to(device), img_t2.to(device)            
        h1 = h_net(img_t1)
        h2 = h_net(img_t2)
        with torch.no_grad():          
            hr = h_net(img_r) #[bs hdim]
            hr = hr.repeat_interleave(bs, dim=0).view(bs,bs, args.h_dim)
        nce_loss = avg_NCE_loss(h1, 
                                 h2, 
                                 hr, 
                                 hr, 
                                 similarity = similarity,
                                 temprature = args.temprature,
                                 )     
        nce_loss.backward()
        h_net_opt.step()        
        
        shuffle_idx = list(range(img_t1.size(0)))        
        random.shuffle(shuffle_idx)          
        img_r = img_t1[shuffle_idx]                                            
        loader2.set_description(
            (
                f' Epoch: {epoch + 1};  NCELoss: {nce_loss.item()}  ' #Enc Losses: {enc_losses.item():.3f};                 
            )
        )
        if vis == True:
            writer.add_scalar("NCE Loss", nce_loss.item(), global_step=epoch, walltime=wt) 
    if vis == True:
        with torch.no_grad(): 
            if epoch % 100 == 0:
                label_lst = label.tolist()
                label_lst = [f'{i}' for i in label_lst]            
                writer.add_embedding(tag="h1", mat=h_net(img_norm), metadata=label_lst, label_img=img_norm , global_step=epoch)            


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--bs', type=int, default=2048)
    parser.add_argument('--dataset', type=str, default='cifar100')
    parser.add_argument('--ds_dir', type=str, default='.')    
    parser.add_argument('--epoch', type=int, default=1800)    
    parser.add_argument('--h_lr', type=float, default=3e-4)   
    parser.add_argument('--h_dim', type=int, default=128)    
    parser.add_argument('--temprature', type=float, default=0.5)   
    parser.add_argument('--weight_decay', type=float, default=1e-6)                                                   
    parser.add_argument('--nw', type=int, default=6)         
    args = parser.parse_args()
           
    ### initialisation of the encoder ### 
    h_net = resnet34(pretrained=False, progress=False, num_classes=args.h_dim)
    h_net = modify_resnet_model(h_net, args , mode='encoder')    
    print("Number of h net Paramters: ", count_parameters(h_net))
    
    ### defining the optimiser #####
    h_net_opt = optim.Adam(h_net.parameters(), lr=args.h_lr, weight_decay=args.weight_decay)    
    h_net = nn.DataParallel(h_net)    
    h_net = h_net.to(device)
    
    ### get the dataloaders ######
    ds_warped = DataSetWrapper(args.dataset, args.ds_dir, args.bs, None , args.nw, mode='encoder')
    loader1 , loader2 = ds_warped.get_loaders()
            
    ### manage directory to save the checkpoint   ./checkpoint/experiment_name/h_net.pt     
    if not os.path.isdir('checkpoint'):
        os.mkdir('checkpoint')        
    exp_num = f'h_{args.dataset}_{args.h_dim}_bs{args.bs}_hlr{args.h_lr}_temp{args.temprature}'        
    
    if vis == True:
        writer = SummaryWriter(f'runs/{exp_num}') 
    
    for epoch in range(args.epoch):
        train(epoch, args, loader1, loader2, h_net, h_net_opt)
        torch.save(
             {'model': h_net.module.state_dict(), 'args': args},
            f'checkpoint/{exp_num}_h_net.pt',
        )

    if vis == True:
        writer.close()

 
    

    